{
    "name":"Champagne Festival",
    "version":"1.0.0",
    "authors":["PB Team"],
    "tag":"CF"
}