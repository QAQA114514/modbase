{
    "name":"Love-Memory",
    "version":"1.0.0",
    "authors":["GreatEffirtLeadsToMiracles233"],
    "tag":"LM"
}