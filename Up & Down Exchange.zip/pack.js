const modInfo = {
  name:"Up & Down Exchange",
  version:"1.0.0",
  authors:["QAQA"],
  tilePrefix:"UDE"
}
