{
    "name":"Love-mory",
    "version":"1.0.0",
    "authors":["QAQA&大力出奇迹"],
    "tag":"iielove"
}
